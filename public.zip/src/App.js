import logo from './logo.svg';
import './App.css';
import Layout from './components/layout';

function App() {
  return (
    <div className="App">
      <Layout></Layout>
    </div>
  );
}

export default App;
